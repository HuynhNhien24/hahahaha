<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\AdminController;

Route::get('/', function () {
    return view('home');
})->name('home');

Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'processLogin']);

    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'processRegister']);
});

Route::middleware('auth')->group(function () {
    Route::post('/attendance', [AdminController::class, 'attendance'])
        ->name('attendance.record');

    Route::post('/logout', [AuthController::class, 'logout'])
        ->name('logout');
});

Route::middleware(['auth','admin'])->group(function () {
    Route::get('/dashboard', [AdminController::class, 'dashboard'])
        ->name('dashboard');

    Route::get('/add-employee', [AdminController::class, 'showAddEmployee'])
        ->name('employee.add');

    Route::post('/add-employee', [AdminController::class, 'storeEmployee'])
        ->name('employee.store');
});

Route::get('/monitor', [AuthController::class, 'attendanceMonitor'])
    ->name('attendance.monitor');
