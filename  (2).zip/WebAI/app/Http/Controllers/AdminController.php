<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Carbon\Carbon;

class AdminController extends Controller
{
    public function dashboard()
    {
        $logs = DB::table('attendance_logs')
            ->orderByDesc('check_in_time')
            ->limit(50)
            ->get();

        $total_staff = DB::table('users')->where('role','employee')->count();

        $today_checkin = DB::table('attendance_logs')
            ->whereDate('check_in_time', Carbon::today())
            ->distinct('name')
            ->count('name');

        return view('auth.dashboard', compact(
            'logs','total_staff','today_checkin'
        ));
    }

    public function showAddEmployee()
    {
        return view('auth.add-employee');
    }

    public function storeEmployee(Request $request)
    {
        $request->validate([
            'name'=>'required|alpha_num',
            'department'=>'required',
            'photos'=>'required|array|min:3'
        ]);

        DB::table('users')->insert([
            'name'=>$request->name,
            'role'=>'employee',
            'department'=>$request->department
        ]);

        $dir = base_path('../faces_db/'.$request->name);
        if(!File::exists($dir)){
            File::makeDirectory($dir,0777,true);
        }

        foreach($request->photos as $i=>$img){
            $data = explode(',', $img);
            file_put_contents(
                $dir.'/'.time().'_'.$i.'.jpg',
                base64_decode($data[1])
            );
        }

        $pkl = base_path('../faces_db/representations_facenet512.pkl');
        if(File::exists($pkl)) File::delete($pkl);

        return redirect()->route('dashboard')
            ->with('success','Thêm nhân viên & dữ liệu khuôn mặt thành công');
    }

    public function attendance()
    {
        $cmd = "cd ../deepface-master && venv/Scripts/python attendance.py";
        $result = shell_exec($cmd);

        $data = json_decode($result,true);

        if(!$data || $data['name']=="Unknown"){
            return back()->withErrors('Không nhận diện được khuôn mặt');
        }

        DB::table('attendance_logs')->insert([
            'name'=>$data['name'],
            'check_in_time'=>now()
        ]);

        return redirect()->route('dashboard')
            ->with('success','Điểm danh thành công: '.$data['name']);
    }
}
