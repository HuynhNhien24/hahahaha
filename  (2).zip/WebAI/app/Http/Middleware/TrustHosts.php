<?php

namespace App\Http\Middleware;

use Illuminate\Http\Request;

class TrustHosts
{
    public function hosts()
    {
        return ['*'];
    }
}
