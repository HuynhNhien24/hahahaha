@extends('layout')

@section('content')

<div class="text-center mb-5">
    <h1 class="fw-bold">🤖 HỆ THỐNG CHẤM CÔNG AI</h1>
    <p class="text-muted">
        Nhận diện khuôn mặt realtime bằng DeepFace (Facenet512)
    </p>
</div>

<div class="row justify-content-center g-4">

    {{-- KHÁCH --}}
    @guest
    <div class="col-md-4">
        <div class="card shadow p-4 text-center">
            <h5>🔐 Đăng nhập</h5>
            <p class="text-muted">Dành cho nhân viên và quản trị</p>
            <a href="{{ route('login') }}" class="btn btn-primary w-100">
                Đăng nhập hệ thống
            </a>
        </div>
    </div>
    @endguest

    {{-- GHI NHẬN CHẤM CÔNG --}}
    <div class="col-md-4">
        <div class="card shadow p-4 text-center">
            <h5>📝 Ghi nhận chấm công</h5>
            <p class="text-muted">
                AI tự động nhận diện khuôn mặt
            </p>

            @auth
            <form method="POST" action="{{ route('attendance.record') }}">
                @csrf
                <button type="submit"
                        class="btn btn-success w-100"
                        onclick="showLoading()">
                    📝 Ghi nhận chấm công
                </button>
            </form>
            @else
            <a href="{{ route('login') }}" class="btn btn-success w-100">
                Đăng nhập để chấm công
            </a>
            @endauth

            {{-- ANIMATION AI --}}
            <div id="loading" class="mt-3 d-none">
                <div class="spinner-border text-success"></div>
                <p class="mt-2">AI đang nhận diện khuôn mặt...</p>
            </div>
        </div>
    </div>

    {{-- ADMIN --}}
    @auth
        @if(auth()->user()->role === 'admin')
        <div class="col-md-4">
            <div class="card shadow p-4 text-center border border-danger">
                <h5>🛠 Quản trị hệ thống</h5>
                <p class="text-muted">Chỉ dành cho Admin</p>
                <a href="{{ route('dashboard') }}" class="btn btn-danger w-100">
                    Vào Dashboard
                </a>
            </div>
        </div>
        @endif
    @endauth

</div>

<hr class="my-5">

{{-- THÔNG TIN HỆ THỐNG --}}
<div class="row">
    <div class="col-md-6">
        <h5>📊 Thông tin hệ thống</h5>
        <table class="table table-bordered">
            <tr>
                <th>AI Engine</th>
                <td>DeepFace – Facenet512</td>
            </tr>
            <tr>
                <th>Backend</th>
                <td>Laravel + Python</td>
            </tr>
            <tr>
                <th>Camera</th>
                <td>Webcam realtime</td>
            </tr>
            <tr>
                <th>Kiến trúc</th>
                <td>Web ↔ AI Backend</td>
            </tr>
        </table>
    </div>

    <div class="col-md-6">
        <h5>ℹ️ Quy trình hoạt động</h5>
        <ul class="list-group">
            <li class="list-group-item">1️⃣ Admin thêm nhân viên</li>
            <li class="list-group-item">2️⃣ Hệ thống huấn luyện AI</li>
            <li class="list-group-item">3️⃣ Nhân viên đứng trước camera</li>
            <li class="list-group-item">4️⃣ AI tự động ghi nhận chấm công</li>
        </ul>
    </div>
</div>

@endsection

@section('scripts')
<script>
function showLoading(){
    document.getElementById('loading').classList.remove('d-none');
}
</script>
@endsection
