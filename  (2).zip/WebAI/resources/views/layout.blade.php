<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>AI Face Attendance System</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

<style>
body { background:#f4f6f9; }
.sidebar {
    min-height:100vh;
    background:#1f2937;
    color:#fff;
}
.sidebar a {
    color:#cbd5e1;
    padding:12px 20px;
    display:block;
    text-decoration:none;
    border-left:4px solid transparent;
}
.sidebar a:hover,
.sidebar a.active {
    background:#111827;
    color:#fff;
    border-left-color:#3b82f6;
}
.topbar {
    background:#fff;
    padding:15px 25px;
    border-bottom:1px solid #e5e7eb;
}
.card {
    border-radius:12px;
}
</style>
</head>

<body>
<div class="row g-0">

<!-- SIDEBAR -->
<div class="col-md-2 sidebar">
    <h4 class="text-center py-4">
        🤖 AI FACE ID
    </h4>

    <a href="{{ route('dashboard') }}" class="{{ request()->is('dashboard') ? 'active' : '' }}">
        <i class="fas fa-chart-line me-2"></i> Dashboard
    </a>

    <a href="{{ route('employee.add') }}" class="{{ request()->is('add-employee') ? 'active' : '' }}">
        <i class="fas fa-user-plus me-2"></i> Thêm nhân viên
    </a>

    <form method="POST" action="{{ route('logout') }}" class="mt-4 px-3">
        @csrf
        <button class="btn btn-danger w-100">
            <i class="fas fa-sign-out-alt me-1"></i> Đăng xuất
        </button>
    </form>
</div>

<!-- CONTENT -->
<div class="col-md-10">
    <div class="topbar d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Hệ thống chấm công AI</h5>
        <span class="badge bg-success">
            <i class="fas fa-circle me-1"></i> AI Online
        </span>
    </div>

    <div class="p-4">
        @if(session('success'))
            <div class="alert alert-success shadow-sm">
                {{ session('success') }}
            </div>
        @endif

        @yield('content')
    </div>
</div>

</div>
</body>
</html>
