@extends('layout')

@section('content')

{{-- TIÊU ĐỀ --}}
<div class="d-flex justify-content-between align-items-center mb-4">
    <h3 class="mb-0">📊 Dashboard quản trị</h3>
    <span class="badge bg-success">
        <i class="fas fa-circle me-1"></i> AI Online
    </span>
</div>

{{-- THỐNG KÊ --}}
<div class="row mb-4">
    <div class="col-md-4">
        <div class="card shadow-sm p-3 bg-primary text-white">
            <h2>{{ $total_staff }}</h2>
            <p class="mb-0">
                <i class="fas fa-users me-1"></i> Tổng nhân viên
            </p>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow-sm p-3 bg-success text-white">
            <h2>{{ $today_checkin }}</h2>
            <p class="mb-0">
                <i class="fas fa-user-check me-1"></i> Đã chấm công hôm nay
            </p>
        </div>
    </div>

    <div class="col-md-4">
        <div class="card shadow-sm p-3 bg-dark text-white">
            <h5 class="mb-2">🤖 AI Engine</h5>
            <span class="badge bg-success">DeepFace – Facenet512</span>
        </div>
    </div>
</div>

{{-- NÚT GHI NHẬN CHẤM CÔNG --}}
<div class="card shadow mb-4">
    <div class="card-body text-center">
        <h5 class="mb-3">📝 Ghi nhận chấm công bằng AI</h5>

        <form method="POST" action="{{ route('attendance.record') }}">
            @csrf
            <button type="submit"
                    class="btn btn-lg btn-success px-5"
                    onclick="showLoading()">
                📸 Ghi nhận chấm công
            </button>
        </form>

        {{-- ANIMATION --}}
        <div id="loading" class="mt-3 d-none">
            <div class="spinner-border text-success"></div>
            <p class="mt-2">AI đang nhận diện khuôn mặt...</p>
        </div>

        <small class="text-muted d-block mt-2">
            Hệ thống sẽ tự động nhận diện khuôn mặt qua webcam
        </small>
    </div>
</div>

{{-- BẢNG LỊCH SỬ --}}
<div class="card shadow">
    <div class="card-header bg-white">
        <h6 class="mb-0 text-primary">
            <i class="fas fa-history me-1"></i> Lịch sử chấm công gần nhất
        </h6>
    </div>

    <div class="card-body p-0">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Nhân viên</th>
                    <th>Thời gian</th>
                    <th>Trạng thái</th>
                </tr>
            </thead>

            <tbody>
            @forelse($logs as $log)
                <tr>
                    <td>{{ $log->id }}</td>

                    <td>
                        <i class="fas fa-user-circle text-primary me-1"></i>
                        {{ $log->name }}
                    </td>

                    <td>
                        <i class="fas fa-clock me-1"></i>
                        {{ $log->check_in_time }}
                    </td>

                    <td>
                        <span class="badge bg-success">
                            ✔ Đã ghi nhận
                        </span>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="4" class="text-center text-muted py-3">
                        Chưa có dữ liệu chấm công
                    </td>
                </tr>
            @endforelse
            </tbody>
        </table>
    </div>
</div>

@endsection

@section('scripts')
<script>
function showLoading(){
    document.getElementById('loading').classList.remove('d-none');
}
</script>
@endsection
