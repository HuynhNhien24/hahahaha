@extends('layout')

@section('content')
<div class="card shadow">
    <div class="card-header bg-primary text-white">
        <h5 class="mb-0">👤 Thêm nhân viên & Huấn luyện AI</h5>
    </div>

    <div class="card-body">
        <form method="POST" action="{{ route('employee.store') }}" onsubmit="return validatePhotos()">
            @csrf

            <div class="row mb-3">
                <div class="col-md-6">
                    <label class="fw-bold">Họ tên (không dấu, viết liền)</label>
                    <input name="name" class="form-control" required pattern="[A-Za-z0-9]+">
                    <small class="text-muted">Dùng làm tên nhận diện AI</small>
                </div>

                <div class="col-md-6">
                    <label class="fw-bold">Phòng ban</label>
                    <select name="department" class="form-select">
                        <option>IT</option>
                        <option>HR</option>
                        <option>Sales</option>
                    </select>
                </div>
            </div>

            <hr>

            <h6 class="text-danger">📸 Chụp ít nhất 3 ảnh khuôn mặt</h6>

            <div class="row mt-3">
                <div class="col-md-6 text-center">
                    <div id="camera" class="border rounded"></div>
                    <button type="button" class="btn btn-warning mt-2" onclick="takeSnapshot()">
                        <i class="fas fa-camera"></i> Chụp ảnh
                    </button>
                </div>

                <div class="col-md-6">
                    <div id="preview" class="d-flex flex-wrap gap-2"></div>
                </div>
            </div>

            <div id="photo_inputs"></div>

            <button class="btn btn-success w-100 mt-4">
                💾 Lưu & Huấn luyện AI
            </button>
        </form>
    </div>
</div>
@endsection

@section('scripts')
<script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.26/webcam.min.js"></script>
<script>
Webcam.set({ width:320,height:240,image_format:'jpeg',jpeg_quality:90 });
Webcam.attach('#camera');

let count = 0;

function takeSnapshot(){
    if(count >= 5){ alert("Tối đa 5 ảnh"); return; }

    Webcam.snap(function(data_uri){
        count++;
        document.getElementById('preview').innerHTML +=
            `<img src="${data_uri}" width="80" class="border rounded">`;

        let input = document.createElement('input');
        input.type = 'hidden';
        input.name = 'photos[]';
        input.value = data_uri;
        document.getElementById('photo_inputs').appendChild(input);
    });
}

function validatePhotos(){
    if(count < 3){
        alert("Cần ít nhất 3 ảnh khuôn mặt!");
        return false;
    }
    return true;
}
</script>
@endsection
