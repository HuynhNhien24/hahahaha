<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>AI Attendance Monitor</title>

<!-- Auto refresh mỗi 5 giây -->
<meta http-equiv="refresh" content="5">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
body {
    background-color: #000;
    color: #00ff88;
    text-align: center;
}
.card {
    background: #111;
    border: 1px solid #00ff88;
}
.time {
    font-size: 1.2rem;
}
</style>
</head>

<body>

<h2 class="my-4">📡 MÀN HÌNH CHẤM CÔNG AI (LIVE)</h2>

@if($latest)
<div class="card mx-auto p-4" style="width:420px">
    <h3 class="mb-2">
        <i class="fas fa-user"></i> {{ $latest->name }}
    </h3>

    <p class="time">
        <i class="fas fa-clock"></i>
        {{ $latest->check_in_time }}
    </p>

    <span class="badge bg-success">
        ✔ Đã điểm danh
    </span>
</div>
@else
<p>Chưa có dữ liệu chấm công</p>
@endif

</body>
</html>
