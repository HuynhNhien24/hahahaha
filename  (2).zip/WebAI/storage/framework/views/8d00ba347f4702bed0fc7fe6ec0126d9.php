<!DOCTYPE html>
<html>
<head>
    <title>Đăng ký Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>body { display: flex; align-items: center; justify-content: center; height: 100vh; background: #f0f2f5; }</style>
</head>
<body>
    <div class="card p-4 shadow" style="width: 400px;">
        <h3 class="text-center mb-3">📝 Đăng Ký Admin</h3>
        <form method="POST" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label>Họ tên</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="mb-3">
                <label>Mật khẩu</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button class="btn btn-success w-100">Đăng ký</button>
            <div class="text-center mt-2">
                <a href="<?php echo e(route('login')); ?>">Quay lại đăng nhập</a>
            </div>
        </form>
    </div>
</body>
</html><?php /**PATH D:\Admin\deepface-master\WebAI\resources\views/auth/register.blade.php ENDPATH**/ ?>