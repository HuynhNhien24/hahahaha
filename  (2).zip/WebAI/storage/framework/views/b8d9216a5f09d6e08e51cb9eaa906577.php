<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hệ thống AI Chấm Công</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f4f6f9; overflow-x: hidden; }
        .sidebar { min-height: 100vh; background: #212529; color: white; padding-top: 20px; }
        .sidebar a { color: #cfd2d6; text-decoration: none; display: block; padding: 12px 20px; border-left: 3px solid transparent; }
        .sidebar a:hover, .sidebar a.active { background: #343a40; color: #fff; border-left-color: #0d6efd; }
        .content { padding: 30px; }
    </style>
</head>
<body>
    <div class="row g-0">
        <div class="col-md-2 sidebar d-none d-md-block">
            <h4 class="text-center mb-4"><i class="fas fa-robot text-primary"></i> AI FACE ID</h4>
            <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->is('/') || request()->is('dashboard') ? 'active' : ''); ?>"><i class="fas fa-tachometer-alt me-2"></i>Dashboard</a>
            <a href="<?php echo e(route('employee.add')); ?>" class="<?php echo e(request()->is('add-employee') ? 'active' : ''); ?>"><i class="fas fa-user-plus me-2"></i>Thêm Nhân viên</a>
            <div class="mt-5 border-top pt-3">
                <a href="<?php echo e(route('logout')); ?>" class="text-danger"><i class="fas fa-sign-out-alt me-2"></i>Đăng xuất</a>
            </div>
        </div>

        <div class="col-md-10 content">
            <?php if(session('success')): ?>
                <div class="alert alert-success shadow-sm"><?php echo e(session('success')); ?></div>
            <?php endif; ?>
            
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html><?php /**PATH D:\Admin\deepface-master\WebAI\resources\views/layout.blade.php ENDPATH**/ ?>