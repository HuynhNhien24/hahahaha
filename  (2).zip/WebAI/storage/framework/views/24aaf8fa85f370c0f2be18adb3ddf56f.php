

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>📊 Giám sát Chấm công</h2>
        <span class="badge bg-success p-2"><i class="fas fa-circle me-1"></i> Live Update (5s)</span>
    </div>
    
    <meta http-equiv="refresh" content="5"> 

    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card bg-primary text-white p-3 shadow-sm">
                <h3><?php echo e($total_staff); ?></h3>
                <p class="mb-0"><i class="fas fa-users"></i> Tổng nhân viên</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-success text-white p-3 shadow-sm">
                <h3><?php echo e($today_checkin); ?></h3>
                <p class="mb-0"><i class="fas fa-check-circle"></i> Có mặt hôm nay</p>
            </div>
        </div>
    </div>

    <div class="card shadow border-0">
        <div class="card-header bg-white py-3">
            <h5 class="mb-0 text-primary">Lịch sử ra vào mới nhất</h5>
        </div>
        <div class="card-body p-0">
            <table class="table table-hover table-striped mb-0">
                <thead class="table-light">
                    <tr>
                        <th>ID</th>
                        <th>Nhân viên</th>
                        <th>Thời gian</th>
                        <th>Trạng thái</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(count($logs) > 0): ?>
                        <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>#<?php echo e($log->id); ?></td>
                            <td><strong><?php echo e($log->user_name); ?></strong></td>
                            <td><?php echo e($log->check_in_time); ?></td>
                            <td>
                                <?php if(str_contains($log->status, 'On Time')): ?>
                                    <span class="badge bg-success"><?php echo e($log->status); ?></span>
                                <?php else: ?>
                                    <span class="badge bg-secondary"><?php echo e($log->status); ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr><td colspan="4" class="text-center text-muted">Chưa có dữ liệu chấm công.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Admin\deepface-master\WebAI\resources\views/dashboard.blade.php ENDPATH**/ ?>