
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-md-9">
        <div class="card shadow-lg border-0">
            <div class="card-header bg-primary text-white py-3">
                <h5 class="mb-0"><i class="fas fa-camera me-2"></i>Thêm Nhân viên & Dữ liệu Khuôn mặt</h5>
            </div>
            <div class="card-body p-4">
                <form action="<?php echo e(route('employee.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Họ tên (Viết liền không dấu)</label>
                            <input type="text" name="name" class="form-control" placeholder="VD: NguyenVanA" required pattern="[a-zA-Z0-9]+" title="Chỉ dùng chữ cái và số">
                            <small class="text-muted">Tên này sẽ dùng làm tên thư mục ảnh.</small>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Phòng ban</label>
                            <select name="department" class="form-select">
                                <option>IT Development</option>
                                <option>HR & Admin</option>
                                <option>Sales</option>
                            </select>
                        </div>
                    </div>

                    <hr class="my-4">

                    <div class="text-center">
                        <label class="d-block fw-bold text-danger mb-3">📸 Yêu cầu: Chụp ít nhất 3 ảnh ở các góc khác nhau</label>
                        
                        <div class="d-flex justify-content-center gap-4 flex-wrap">
                            <div class="camera-box">
                                <div id="my_camera" style="border: 2px solid #000; border-radius: 5px;"></div>
                                <button type="button" class="btn btn-warning w-100 mt-2" onClick="take_snapshot()">
                                    <i class="fas fa-camera"></i> CHỤP ẢNH
                                </button>
                            </div>

                            <div class="result-box" style="width: 320px;">
                                <div id="results" class="d-flex flex-wrap gap-2 justify-content-center p-2 bg-light rounded border" style="min-height: 240px;">
                                    <span class="text-muted align-self-center">Ảnh đã chụp hiện ở đây...</span>
                                </div>
                                <button type="button" class="btn btn-danger w-100 mt-2" onClick="reset_camera()">
                                    <i class="fas fa-trash"></i> Chụp lại
                                </button>
                            </div>
                        </div>
                    </div>
                    
                    <div id="image_inputs"></div>

                    <div class="d-grid mt-5">
                        <button type="submit" class="btn btn-primary btn-lg">💾 LƯU DỮ LIỆU VÀO HỆ THỐNG AI</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.26/webcam.min.js"></script>
<script language="JavaScript">
    Webcam.set({
        width: 320,
        height: 240,
        image_format: 'jpeg',
        jpeg_quality: 90
    });
    Webcam.attach('#my_camera');

    let photoCount = 0;

    function take_snapshot() {
        if(photoCount >= 5) { alert("Chỉ chụp tối đa 5 tấm!"); return; }

        Webcam.snap(function(data_uri) {
            photoCount++;
            // Xóa dòng chữ hướng dẫn nếu có
            if(photoCount === 1) document.getElementById('results').innerHTML = '';

            // Hiển thị ảnh nhỏ
            document.getElementById('results').innerHTML += 
                '<img src="'+data_uri+'" class="rounded border border-success" style="width:80px; height:60px; object-fit:cover"/>';
            
            // Tạo input ẩn
            let input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'photos[]';
            input.value = data_uri;
            document.getElementById('image_inputs').appendChild(input);
        });
    }

    function reset_camera() {
        photoCount = 0;
        document.getElementById('results').innerHTML = '<span class="text-muted align-self-center">Ảnh đã chụp hiện ở đây...</span>';
        document.getElementById('image_inputs').innerHTML = '';
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Admin\deepface-master\WebAI\resources\views/add-employee.blade.php ENDPATH**/ ?>