import cv2
import json
import os
from deepface import DeepFace
from datetime import datetime

DB_PATH = "faces_db"
MODEL_NAME = "Facenet512"

cap = cv2.VideoCapture(0)
recognized_name = "Unknown"

ret, frame = cap.read()

if ret:
    try:
        result = DeepFace.find(
            img_path=frame,
            db_path=DB_PATH,
            model_name=MODEL_NAME,
            enforce_detection=False
        )

        if len(result) > 0 and len(result[0]) > 0:
            identity = result[0].iloc[0]["identity"]
            recognized_name = os.path.basename(os.path.dirname(identity))
    except Exception as e:
        recognized_name = "Unknown"

cap.release()

output = {
    "name": recognized_name,
    "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
}

print(json.dumps(output))
