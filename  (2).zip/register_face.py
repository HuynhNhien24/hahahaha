import cv2
import os

# Tên người muốn đăng ký
name = input("Nhập tên nhân viên mới (viet lien khong dau): ")

# Tạo thư mục
save_path = f"faces_db/{name}"
if not os.path.exists(save_path):
    os.makedirs(save_path)

cap = cv2.VideoCapture(0)
count = 0

print(f"Hệ thống sẽ chụp 5 tấm ảnh cho {name}. Hãy xoay nhẹ mặt...")

while True:
    ret, frame = cap.read()
    if not ret: break
    
    cv2.imshow('Dang ky khuon mat', frame)
    
    key = cv2.waitKey(1)
    if key == ord('s'): # Bấm 's' để chụp
        img_name = f"{save_path}/{name}_{count}.jpg"
        cv2.imwrite(img_name, frame)
        print(f"Đã lưu ảnh {count+1}/5: {img_name}")
        count += 1
    
    elif key == ord('q') or count >= 5: # Chụp đủ 5 tấm thì dừng
        break

cap.release()
cv2.destroyAllWindows()
print("✅ Đăng ký thành công! Hãy xóa file .pkl cũ và chạy lại attendance.py")