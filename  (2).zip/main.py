"""
Tác giả: Trần Quốc Vũ_Nhóm 5AnhTai_0869226687
"""
from deepface import DeepFace

print("Đang khởi chạy model... Vui lòng chờ trong giây lát...")

# Thay thế tên file ảnh của bạn vào đây
img1_path = "anh1.jpg"
img2_path = "anh2.jpg"

try:
    # Lệnh verify dùng để so sánh xem 2 ảnh có phải cùng 1 người không
    # Lần chạy đầu tiên nó sẽ tự tải file weight về (khoảng 500MB)
    result = DeepFace.verify(img1_path = img1_path, img2_path = img2_path)
    
    print("-----------------------------------------")
    print("Kết quả so sánh:")
    print("Có phải cùng một người không?: ", result["verified"])
    print("Độ sai lệch (Distance): ", result["distance"])
    print("-----------------------------------------")

except Exception as e:
    print(f"Có lỗi xảy ra: {e}")PS C:\Users\Admin> Set-ExecutionPolicy RemoteSigned
Set-ExecutionPolicy : Access to the registry key
'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\PowerShell\1\ShellIds\Microsoft.PowerShell' is denied. To change the execution
policy for the default (LocalMachine) scope, start Windows PowerShell with the "Run as administrator" option. To
change the execution policy for the current user, run "Set-ExecutionPolicy -Scope CurrentUser".
At line:1 char:1
+ Set-ExecutionPolicy RemoteSigned
+ ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    + CategoryInfo          : PermissionDenied: (:) [Set-ExecutionPolicy], UnauthorizedAccessException
    + FullyQualifiedErrorId : System.UnauthorizedAccessException,Microsoft.PowerShell.Commands.SetExecutionPolicyComma
   nd
PS C:\Users\Admin> y
y : The term 'y' is not recognized as the name of a cmdlet, function, script file, or operable program. Check the
spelling of the name, or if a path was included, verify that the path is correct and try again.
At line:1 char:1
+ y
+ ~
    + CategoryInfo          : ObjectNotFound: (y:String) [], CommandNotFoundException
    + FullyQualifiedErrorId : CommandNotFoundException

PS C:\Users\Admin>
